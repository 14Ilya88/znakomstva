<nav class="navbar navbar-expand-sm navbar-dark bg-info">
    <div class="container-fluid">
        <a class="navbar-brand ms-2">
            <img src="assets/img/logo.svg" alt="" width="50"> Сайт знакомств</a>
        </button>
        <div class="container" align="center">
            <a class="navbar-brand" href="#" align="center">
                <img src="assets/img/arrow.png" alt="" width="50"> Наверх</a>
        </div>
        <ul class="navbar-nav ms-auto mb-3 me-3 mt-1">
            <li class="nav-item">
                <a class="nav-link active">Команда Смирновой 2022</a>
            </li>
        </ul>
</nav>